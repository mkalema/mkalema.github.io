const products = [];

module.exports = class Product {

    constructor(id, name, price, description) {
        this._id = id;
        this._name = name;
        this._price = price;
        this._description = description;
    }

    save() {
        products.push(this);
    }

    static getAll(){
        return products;
    }
}